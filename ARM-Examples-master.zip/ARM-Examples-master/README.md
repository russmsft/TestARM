# ARM-Examples
Example Azure Resource Manager templates


<a href="https://portal.azure.com/#create/microsoft.template/uri/https%3A%2F%2Fraw.githubusercontent.com%2Fross-p-smith%2FARM-Examples%2Fmaster%2FscaleSet.json" target="_blank">
    <img src="http://azuredeploy.net/deploybutton.svg"/>
</a>
<a href="http://armviz.io/#/?load=https://raw.githubusercontent.com/ross-p-smith/ARM-Examples/master/scaleSet.json" target="_blank">
    <img src="http://armviz.io/visualizebutton.png"/>
</a>
